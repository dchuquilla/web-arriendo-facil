<?php
/**
 * Theme functions for Mi Tema Child - Hospedajes
 */

if ( ! defined('ABSPATH') ) { exit; }

/**
 * Enqueue parent + child styles and child scripts.
 */
function twentytwentyfive_child_enqueue_assets() {
  $parent_style_handle = 'parent-style';

  // Parent style (si el padre lo expone por style.css)
  wp_enqueue_style(
    $parent_style_handle,
    get_template_directory_uri() . '/style.css',
    array(),
    wp_get_theme(get_template())->get('Version')
  );

  // Child style (con cache busting basado en modificación del archivo)
  wp_enqueue_style(
    'twentytwentyfive-child-style',
    get_stylesheet_uri(),
    array($parent_style_handle),
    filemtime( get_stylesheet_directory() . '/style.css' )
  );

  // Lightbox para bloques de galería (site-wide; no-op si no hay galerías)
  wp_enqueue_script(
    'twentytwentyfive-child-gallery-lightbox',
    get_stylesheet_directory_uri() . '/assets/js/gallery-lightbox.js',
    array(),
    wp_get_theme()->get('Version'),
    true
  );

  // Search bar (global)
  wp_enqueue_script(
    'twentytwentyfive-child-search-bar',
    get_stylesheet_directory_uri() . '/assets/js/search-bar.js',
    array(),
    filemtime( get_stylesheet_directory() . '/assets/js/search-bar.js' ),
    true
  );

  // Warm likely next pages (property detail and properties list) to improve perceived navigation speed.
  wp_enqueue_script(
    'twentytwentyfive-child-nav-prefetch',
    get_stylesheet_directory_uri() . '/assets/js/nav-prefetch.js',
    array(),
    '1.0.0',
    true
  );

  // JS para el carrusel solo en homepage
  if ( is_front_page() ) {
    wp_enqueue_script(
      'twentytwentyfive-child-home',
      get_stylesheet_directory_uri() . '/assets/js/home.js',
      array(),
      '2.0.3',
      true
    );

    wp_enqueue_script(
      'twentytwentyfive-child-hero-search',
      get_stylesheet_directory_uri() . '/assets/js/hero-search.js',
      array(),
      filemtime( get_stylesheet_directory() . '/assets/js/hero-search.js' ),
      true
    );

    // Data para el carrusel (propiedades destacadas)
    $properties = twentytwentyfive_child_get_featured_properties_payload();
    wp_localize_script('twentytwentyfive-child-home', 'twentytwentyfive_HOME', array(
      'properties' => $properties,
    ));
  }

  // Leaflet.js y estilos para página de búsqueda
  if ( is_page('search-results') || is_singular('accommodation') ) {
    wp_enqueue_style(
      'leaflet-css',
      'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css',
      array(),
      '1.9.4'
    );

    wp_enqueue_script(
      'leaflet-js',
      'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js',
      array(),
      '1.9.4',
      true
    );

    wp_enqueue_style(
      'twentytwentyfive-child-search-results',
      get_stylesheet_directory_uri() . '/assets/css/search-results.css',
      array( 'twentytwentyfive-child-style' ),
      filemtime( get_stylesheet_directory() . '/assets/css/search-results.css' )
    );

    wp_enqueue_script(
      'twentytwentyfive-child-search-results',
      get_stylesheet_directory_uri() . '/assets/js/search-results-interactive.js',
      array( 'leaflet-js' ),
      filemtime( get_stylesheet_directory() . '/assets/js/search-results-interactive.js' ),
      true
    );
  }
}
add_action('wp_enqueue_scripts', 'twentytwentyfive_child_enqueue_assets', 20);

/**
 * Obtiene propiedades destacadas desde Posts (categoría: propiedades-destacadas)
 * Ajusta esto a CPT/ACF si tu proyecto lo requiere.
 */
function twentytwentyfive_child_get_featured_properties_payload() {
  $payload = array();

  $q = new WP_Query(array(
    'post_type'      => 'post',
    'posts_per_page' => 6,
    'post_status'    => 'publish',
    'ignore_sticky_posts' => true,
    'category_name'  => 'propiedades-destacadas',
  ));

  if ( $q->have_posts() ) {
    while ( $q->have_posts() ) {
      $q->the_post();

      $img = get_the_post_thumbnail_url(get_the_ID(), 'large');
      if ( ! $img ) {
        $img = get_stylesheet_directory_uri() . '/assets/img/placeholder.jpg';
      }

      // Campos opcionales por meta (si luego quieres mapearlos desde ACF)
      $location = get_post_meta(get_the_ID(), 'property_location', true);
      $price    = get_post_meta(get_the_ID(), 'property_price_per_night', true);

      $payload[] = array(
        'id'       => get_the_ID(),
        'title'    => get_the_title(),
        'permalink'=> get_permalink(),
        'image'    => esc_url_raw($img),
        'location' => $location ? $location : 'Ubicación por definir',
        'price'    => $price ? $price : '$xx por noche',
        'badges'   => array('Limpieza incluida', 'Mantenimiento 24/7', 'Gestión completa'),
      );
    }
    wp_reset_postdata();
  }

  // Fallback si no hay posts en la categoría
  if ( empty($payload) ) {
    $placeholder = get_stylesheet_directory_uri() . '/assets/img/placeholder.jpg';
    for ($i=1; $i<=3; $i++){
      $payload[] = array(
        'id' => 0,
        'title' => 'Propiedad Destacada #' . $i,
        'permalink' => '#',
        'image' => esc_url_raw($placeholder),
        'location' => 'Quito / Guayaquil',
        'price' => '$xx por noche',
        'badges' => array('Limpieza incluida', 'Mantenimiento 24/7', 'Gestión completa'),
      );
    }
  }

  return $payload;
}

/**
 * Obtiene imágenes del post para carousel desde galería WP o attachments.
 * Retorna array de imágenes con URLs full y comprimidas para blur.
 */
function twentytwentyfive_child_get_accommodation_gallery_images($post_id) {
  if (!$post_id) {
    return [];
  }

  $images = [];
  $post = get_post($post_id);

  if (!$post || !$post->post_content) {
    return [];
  }

  // Primero intentar extraer imágenes de bloque de galería WP
  if (has_block('gallery', $post)) {
    $pattern = '/<img[^>]+src=[\'"]([^\'"]+)[\'"][^>]*(?:data-id=[\'"]([^\'"]+)[\'"])?/';
    if (preg_match_all($pattern, $post->post_content, $matches)) {
      foreach ($matches[1] as $index => $src) {
        $attachment_id = $matches[2][$index] ?? 0;

        // Intentar obtener datos del attachment si existe
        if ($attachment_id && is_numeric($attachment_id)) {
          $full_url = wp_get_attachment_image_src($attachment_id, 'large');
          $thumb_url = wp_get_attachment_image_src($attachment_id, 'thumbnail');

          if ($full_url && $thumb_url) {
            $images[] = [
              'id'        => $attachment_id,
              'url'       => $full_url[0],
              'url_small' => $thumb_url[0],
              'alt'       => get_post_meta($attachment_id, '_wp_attachment_image_alt', true),
            ];
          }
        } else {
          // Si no tenemos ID, usar la URL directa
          if (!empty($src)) {
            $images[] = [
              'id'        => 0,
              'url'       => $src,
              'url_small' => $src, // Fallback
              'alt'       => '',
            ];
          }
        }
      }
    }

    if (!empty($images)) {
      return $images;
    }
  }

  // Fallback: obtener todos los attachments del post
  $attachments = get_posts([
    'post_type'      => 'attachment',
    'post_mime_type' => 'image',
    'post_parent'    => $post_id,
    'posts_per_page' => -1,
    'orderby'        => 'menu_order ID',
    'order'          => 'ASC',
  ]);

  if (!empty($attachments)) {
    foreach ($attachments as $attachment) {
      $full_url = wp_get_attachment_image_src($attachment->ID, 'large');
      $thumb_url = wp_get_attachment_image_src($attachment->ID, 'thumbnail');

      if ($full_url && $thumb_url) {
        $images[] = [
          'id'        => $attachment->ID,
          'url'       => $full_url[0],
          'url_small' => $thumb_url[0],
          'alt'       => get_post_meta($attachment->ID, '_wp_attachment_image_alt', true),
        ];
      }
    }
  }

  return $images;
}

/**
 * Enqueue carousel script only on single accommodation pages.
 */
function twentytwentyfive_child_enqueue_single_carousel() {
  if (!is_singular('accommodation')) {
    return;
  }

  wp_enqueue_script(
    'twentytwentyfive-child-single-carousel',
    get_stylesheet_directory_uri() . '/assets/js/single.js',
    [],
    filemtime(get_stylesheet_directory() . '/assets/js/single.js'),
    true
  );

  $post_id = get_the_ID();
  $gallery_images = twentytwentyfive_child_get_accommodation_gallery_images($post_id);

  wp_localize_script(
    'twentytwentyfive-child-single-carousel',
    'singleCarouselData',
    [
      'images' => $gallery_images,
    ]
  );
}
add_action('wp_enqueue_scripts', 'twentytwentyfive_child_enqueue_single_carousel', 15);

/**
 * Menú principal (si el tema padre no lo registra o quieres controlarlo).
 */
function twentytwentyfive_child_register_menus() {
  register_nav_menus(array(
    'primary' => __('Menú principal', 'twentytwentyfive-child'),
  ));
}
add_action('after_setup_theme', 'twentytwentyfive_child_register_menus', 5);